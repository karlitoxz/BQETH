<?PHP
header('Access-Control-Allow-Origin: *');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>SATEL code generate</title>
	<script src="js/jquery.js"></script>
	<script src="js/jquery.csv-0.71.min.js"></script>
	
	<!-- This exposes the library as a global variable: ethers -->
<script src="js/ethers-v4.min.js" charset="utf-8" type="text/javascript">
</script>
	<script src="js/generatekey.js"></script>
</head>
<body>
	<div id="content"></div>
</body>
</html>
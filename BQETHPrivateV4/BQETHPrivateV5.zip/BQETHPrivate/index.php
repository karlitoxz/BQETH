<?PHP
header('Access-Control-Allow-Origin: *');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>SATEL code</title>
	<script src="js/jquery.js"></script>
	<script src="js/jquery.csv-0.71.min.js"></script>
	<script src="js/index.js"></script>
</head>
<body>
	<div id="content"></div>
</body>
</html>